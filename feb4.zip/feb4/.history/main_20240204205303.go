package main

import (
	"fmt"
	"log"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

func main() {
	endpoint := "192.169.122.1:9000"
	accessKeyID := "n7Uql8oQmtU2IVhe6wwL"
	secretAccessKey := "ARPPuvJlWwvV1D6dgOnm2UQNu1ODX7X0OlJxeRiq"
	useSSL := false
	fmt.Println("Starting initialisation")

	// Initialize minio client object.
	minioClient, err := minio.New(endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(accessKeyID, secretAccessKey, ""),
		Secure: useSSL,
	})
	if err != nil {
		log.Fatalln(err)
	}

	// buckets, err := minioClient.ListBuckets(context.Background())
	// if err != nil {
	// 	fmt.Println(err)
	// 	return
	// }
	// for _, bucket := range buckets {
	// 	fmt.Println(bucket)
	// }

	log.Printf("%#v\n", minioClient) // minioClient is now set up
}
