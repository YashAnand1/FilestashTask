//https://www.youtube.com/watch?v=3JtZqqrJFmM&list=PL5dTjWUk_cPYztKD7WxVFluHvpBNM28N9&index=17

package main

import (
	"fmt"
	"ims-server/routes"

	"github.com/TwiN/go-color"
	"github.com/gofiber/fiber"
)

func setupRoutes(app *fiber.App) {
	app.Post("/api/v1/create/keyvalue", routes.CreateKeyValue)
	app.Delete("/api/v1/delete/keyvalue", routes.DeleteKeyValue)
	app.Get("/api/v1/find/keyvalue", routes.FindKeyValue)
	app.Post("/api/v1/update/log", routes.UpdateLog)
	app.Get("/api/v1/findold/keyvalue", routes.FindOldKeyValue)
	// app.Post("/api/v1/lead", lead.NewLead)
	// app.Delete("/api/v1/lead/:id", lead.DeleteLead)
}

func main() {
cmd := exec.Command("gnome-terminal --tab -- "etcd"")
out, err := cmd.Output()

if err != nil {
	panic(err)
}

fmt.Println(string(out))
	// for removing all data remove directory /var/lib/etcd/default   and restart etcd service
	banner()
	app := fiber.New()
	//initDatabase()
	setupRoutes(app)
	app.Listen(3000)
	// defer database.DBConn.Close()
}

func banner() {
	dashes := `----------------------------------------------------------------------------`
	asciiArt := `    ______  ________
   /  _/  |/  / ___/	I N V E N T O R Y  M A N A G E M E N T  S Y S T E M
   / // /|_/ /\__ \ 	     
 _/ // /  / /___/ /	   - S E R V E R  A P P L I C A T I O N  v1.9 -
/___/_/  /_//____/ 		    `
	fmt.Print("\033c")
	//fmt.Printf("")
	// fmt.Println(asciiArt)
	fmt.Println(color.Ize(color.Bold+color.White, dashes))
	fmt.Println(color.Ize(color.Bold+color.Cyan, asciiArt))
	fmt.Println(color.Ize(color.Bold+color.White, dashes))
	fmt.Println(color.Ize(color.Green+color.Bold, "Initiating the Server..."))
	fmt.Println(color.Ize(color.Bold+color.White, dashes))
}
