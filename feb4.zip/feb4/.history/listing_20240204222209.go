// This code is a work in progress - Contains manual filtering based on accessID & secret-key rather than filtering based on policies.

package main

import (
	"context"
	"fmt"
	"log"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

var secretAccessKey string
var accessKeyID string

func main() {
	endpoint := "127.0.0.1:9000" //my endpoint of where i am running the minio server

	user := "Yash"

	if user == "Yash" {
		accessKeyID := "5CFKL8PrWtDZwBcEz204"                         //yash's user's accesskey
		secretAccessKey := "G2W1stlAatTrLgTTGIxTB7Aq9UeE4s9i7m6qdm2M" // yash's usser's secret key
	} else if user == "Himanshu" {
		accessKeyID := "5CFKL8PrWtDZwBcEz204"                         //Himanshu's user's accesskey
		secretAccessKey := "G2W1stlAatTrLgTTGIxTB7Aq9UeE4s9i7m6qdm2M" // Himanshu's usser's secret key
	}
	////////////////
	///// YASH ///// ===================> Access to all buckets
	////////////////

	// useSSL := false //i did not set this up so i could just leave this line blank and the default would be false as well
	fmt.Println("Starting initialization\n") // for displaying where i am in the code, for my own use // can be removed

	////// connecting minio /////////////////////////////////////////////////////
	minioClient, err := minio.New(endpoint, &minio.Options{
		Creds: credentials.NewStaticV4(accessKeyID, secretAccessKey, ""), /// this is the accessid and secret key of each user!!!
		// Secure: useSSL,  /// commented this out because ssl is not set up
	})

	if err != nil {
		log.Fatalln(err) // for loggin purposes/displaying any error in case connection gets failed
	}

	log.Printf("%#v\n", minioClient) // success message for my own reference // can be removed

	// log.Printf("Printing username and possibly its policy as well") // success message for my own reference // can be removed
	// fmt.Println(minio.NewPostPolicy())
	// fmt.Println(minioClient.EndpointURL().User)

	////// Listing specific buckets depending on specific keys //////////////////////////////////////
	buckets, err := minioClient.ListBuckets(context.Background())
	if err != nil {
		log.Fatalln("Error listing buckets:", err)
	}
	for _, bucket := range buckets { /// this displays all of the keys exactly like filestash does, this is assigned to admin!
		log.Println(bucket) //this prints bucket info wih its name and meta
	}
}
}