package main

import (
	"context"
	"fmt"
	"log"

	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

func main() {
	endpoint := "127.0.0.1:9000"
	accessKeyID := "5CFKL8PrWtDZwBcEz204"
	secretAccessKey := "G2W1stlAatTrLgTTGIxTB7Aq9UeE4s9i7m6qdm2M"

	fmt.Println("Starting initialization")

	// Connect to MinIO
	minioClient, err := minio.New(endpoint, &minio.Options{
		Creds: credentials.NewStaticV4(accessKeyID, secretAccessKey, ""),
	})

	if err != nil {
		log.Fatalln(err)
	}

	log.Printf("%#v\n", minioClient)

	// List buckets
	buckets, err := minioClient.ListBuckets(context.Background())
	if err != nil {
		log.Fatalln("Error listing buckets:", err)
	}

	for _, bucket := range buckets {
		log.Println(bucket.Name)

		// Retrieve and print the policies for each user associated with the bucket
		users, err := minioClient.ListUsers(context.Background(), bucket.Name)
		if err != nil {
			log.Printf("Error listing users for bucket %s: %v\n", bucket.Name, err)
		} else {
			for _, user := range users {
				log.Printf("User %s - Policy: %s\n", user.AccessKey, user.PolicyName)
			}
		}
	}
}
